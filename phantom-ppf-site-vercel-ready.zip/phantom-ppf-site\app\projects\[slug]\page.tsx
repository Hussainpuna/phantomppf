import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight, MessageCircle } from "lucide-react";
import { Footer } from "@/app/components/Footer";
import { Header } from "@/app/components/Header";
import { QuoteForm } from "@/app/components/QuoteForm";
import { ScrollReveal } from "@/app/components/ScrollReveal";
import { brand, projects } from "@/app/site-data";

type PageProps = {
  params: Promise<{ slug: string }>;
};

export function generateStaticParams() {
  return projects.map((project) => ({ slug: project.slug }));
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const project = projects.find((item) => item.slug === slug);
  if (!project) return {};

  return {
    title: `${project.title} | Phantom PPF Dubai`,
    description: `${project.title} service brief by Phantom PPF & Auto Care in Dubai. Request a tailored quotation for your vehicle.`,
    alternates: { canonical: `/projects/${project.slug}` },
    openGraph: {
      title: project.title,
      description: project.text,
      images: [project.image],
    },
  };
}

export default async function Page({ params }: PageProps) {
  const { slug } = await params;
  const project = projects.find((item) => item.slug === slug);
  if (!project) notFound();

  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: brand.siteUrl },
      {
        "@type": "ListItem",
        position: 2,
        name: "Gallery",
        item: `${brand.siteUrl}/#gallery`,
      },
      {
        "@type": "ListItem",
        position: 3,
        name: project.title,
        item: `${brand.siteUrl}/projects/${project.slug}`,
      },
    ],
  };

  return (
    <main>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }}
      />
      <Header />
      <ScrollReveal />
      <section className="service-hero">
        <img src={project.image} alt={`${project.title} visual`} />
        <div className="hero-overlay" />
        <div className="section-inner service-hero-content reveal">
          <nav className="breadcrumbs" aria-label="Breadcrumb">
            <Link href="/">Home</Link>
            <span>/</span>
            <Link href="/#gallery">Gallery</Link>
            <span>/</span>
            <strong>{project.vehicle}</strong>
          </nav>
          <span className="section-kicker">{project.service}</span>
          <h1>{project.title}</h1>
          <p>{project.text}</p>
          <div className="hero-actions">
            <Link className="btn btn-primary" href="#quote">
              Request Similar Work
              <ArrowRight size={18} />
            </Link>
            <a className="btn btn-outline" href={brand.whatsappQuote}>
              <MessageCircle size={18} />
              WhatsApp Phantom
            </a>
          </div>
        </div>
      </section>
      <section className="section">
        <div className="section-inner service-layout">
          <aside className="service-sidebar reveal">
            <h2>Project Brief</h2>
            <p>Vehicle: {project.vehicle}</p>
            <p>Service: {project.service}</p>
            <p>Finish: {project.finish}</p>
          </aside>
          <div className="service-content">
            <section className="content-panel reveal">
              <h2>Approach</h2>
              <p>
                Phantom starts with inspection, confirms the service scope, prepares the
                surface and finishes the vehicle with a detailed quality check before handover.
              </p>
            </section>
            <section className="content-panel reveal">
              <h2>Recommended Next Services</h2>
              <div className="option-grid">
                <Link href="/services/paint-protection-film">Paint Protection Film</Link>
                <Link href="/services/ceramic-coating">Ceramic Coating</Link>
                <Link href="/services/window-tinting">Window Tinting</Link>
                <Link href="/services/car-detailing">Car Detailing</Link>
              </div>
            </section>
            <QuoteForm compact />
          </div>
        </div>
      </section>
      <Footer />
    </main>
  );
}
