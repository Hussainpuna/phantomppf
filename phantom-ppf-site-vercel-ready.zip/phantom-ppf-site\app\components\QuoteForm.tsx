"use client";

import { FormEvent, useState } from "react";
import { MessageCircle, Upload } from "lucide-react";
import { brand, serviceOptions } from "../site-data";

export function QuoteForm({ compact = false }: { compact?: boolean }) {
  const [sent, setSent] = useState(false);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSent(true);
  }

  return (
    <div className={compact ? "quote-card compact" : "quote-card"} id="quote">
      <div className="section-kicker">Workshop booking</div>
      <h2>Request a Vehicle Quotation</h2>
      <p>
        Share your vehicle details and the Phantom team will contact you shortly.
        WhatsApp is always available for faster quoting.
      </p>

      {sent ? (
        <div className="form-success" role="status">
          <strong>Thank you. The Phantom team will contact you shortly.</strong>
          <a className="btn btn-primary" href={brand.whatsappQuote}>
            <MessageCircle size={18} />
            Continue on WhatsApp
          </a>
        </div>
      ) : (
        <form className="quote-form" onSubmit={handleSubmit}>
          <label>
            Full name
            <input name="name" type="text" required />
          </label>
          <label>
            Phone number
            <input name="phone" type="tel" required />
          </label>
          <label>
            WhatsApp number
            <input name="whatsapp" type="tel" />
          </label>
          <label>
            Vehicle make
            <input name="make" type="text" />
          </label>
          <label>
            Vehicle model
            <input name="model" type="text" />
          </label>
          <label>
            Vehicle year
            <input name="year" type="number" min="1980" max="2035" />
          </label>
          <label>
            Required service
            <select name="service" required defaultValue="">
              <option value="" disabled>
                Select service
              </option>
              {serviceOptions.map((option) => (
                <option key={option}>{option}</option>
              ))}
            </select>
          </label>
          <label>
            PPF finish if applicable
            <select name="finish" defaultValue="">
              <option value="">Not applicable</option>
              <option>Glossy PPF</option>
              <option>Matte PPF</option>
              <option>Colour PPF</option>
              <option>Full-body protection</option>
            </select>
          </label>
          <label>
            Preferred date
            <input name="date" type="date" />
          </label>
          <label className="file-label">
            Upload vehicle images
            <span>
              <Upload size={16} />
              Choose images
            </span>
            <input name="images" type="file" accept="image/*" multiple />
          </label>
          <label className="full-span">
            Additional message
            <textarea name="message" rows={4} />
          </label>
          <div className="form-actions full-span">
            <button className="btn btn-primary" type="submit">
              Get a Free Quote
            </button>
            <a className="btn btn-outline" href={brand.whatsappQuote}>
              <MessageCircle size={18} />
              Direct WhatsApp
            </a>
          </div>
        </form>
      )}
    </div>
  );
}
