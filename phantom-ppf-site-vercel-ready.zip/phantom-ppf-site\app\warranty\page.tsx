import type { Metadata } from "next";
import Link from "next/link";
import { ExternalLink, MessageCircle, ShieldCheck } from "lucide-react";
import { Footer } from "../components/Footer";
import { Header } from "../components/Header";
import { QuoteForm } from "../components/QuoteForm";
import { ScrollReveal } from "../components/ScrollReveal";
import { brand } from "../site-data";

export const metadata: Metadata = {
  title: "Check Phantom PPF Warranty | Warranty Portal and Support",
  description:
    "Use the Phantom PPF warranty portal to review coverage details and contact Phantom for warranty support in Dubai and the UAE.",
  alternates: { canonical: "/warranty" },
};

export default function Page() {
  return (
    <main>
      <Header />
      <ScrollReveal />
      <section className="plain-hero">
        <div className="section-inner reveal">
          <nav className="breadcrumbs" aria-label="Breadcrumb">
            <Link href="/">Home</Link>
            <span>/</span>
            <strong>Warranty</strong>
          </nav>
          <span className="section-kicker">Warranty support</span>
          <h1>Check Your Phantom PPF Warranty</h1>
          <p>
            Already protected your vehicle with Phantom PPF? Access the official warranty
            portal to review your coverage and warranty details.
          </p>
          <div className="hero-actions">
            <a className="btn btn-primary" href={brand.warranty} target="_blank" rel="noreferrer">
              Check Warranty Details
              <ExternalLink size={18} />
            </a>
            <a className="btn btn-outline" href={brand.whatsappQuote}>
              <MessageCircle size={18} />
              Warranty Support
            </a>
          </div>
        </div>
      </section>
      <section className="section">
        <div className="section-inner service-layout">
          <aside className="service-sidebar reveal">
            <ShieldCheck size={32} />
            <h2>Important Note</h2>
            <p>
              Phantom does not publish warranty duration or coverage terms on this page.
              Always check the official portal for current details.
            </p>
          </aside>
          <div className="service-content">
            <section className="content-panel reveal">
              <h2>How to Check Your Warranty</h2>
              <ol className="number-list">
                <li>Open the warranty portal in a new tab.</li>
                <li>Enter the requested vehicle or warranty information.</li>
                <li>Review the coverage details shown in the portal.</li>
                <li>Contact Phantom if anything is unclear.</li>
              </ol>
            </section>
            <section className="content-panel reveal">
              <h2>Information You May Need</h2>
              <div className="option-grid">
                <span>Vehicle make and model</span>
                <span>Vehicle plate or reference details</span>
                <span>Service date or invoice reference</span>
                <span>Registered customer contact details</span>
              </div>
            </section>
            <section className="content-panel reveal">
              <h2>General Care Responsibilities</h2>
              <p>
                Follow the aftercare guidance provided at handover, avoid aggressive
                chemicals, inspect edges periodically and contact Phantom promptly if you
                notice lifting, damage or unusual surface behavior.
              </p>
            </section>
            <QuoteForm compact />
          </div>
        </div>
      </section>
      <Footer />
    </main>
  );
}
