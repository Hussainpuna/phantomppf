import type { Metadata, Viewport } from "next";
import "./globals.css";
import { brand } from "./site-data";

export const metadata: Metadata = {
  metadataBase: new URL(brand.siteUrl),
  title: {
    default: "Phantom PPF & Auto Care | Complete Car Protection in the UAE",
    template: "%s | Phantom PPF & Auto Care",
  },
  description:
    "Complete car protection, styling and maintenance in Dubai and the UAE, including PPF, ceramic coating, window tinting, painting, detailing and oil change.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
  openGraph: {
    type: "website",
    siteName: "Phantom PPF & Auto Care",
    images: ["/assets/hero.webp"],
  },
  robots: {
    index: true,
    follow: true,
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#070708",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
