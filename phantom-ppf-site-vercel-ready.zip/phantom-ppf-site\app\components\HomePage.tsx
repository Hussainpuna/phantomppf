import Link from "next/link";
import {
  ArrowRight,
  BadgeCheck,
  CalendarCheck,
  Car,
  CheckCircle2,
  Clock,
  Download,
  ExternalLink,
  Mail,
  MapPin,
  MessageCircle,
  Phone,
  ShieldCheck,
  Sparkles,
  Star,
  Wrench,
} from "lucide-react";
import { BeforeAfterSlider } from "./BeforeAfterSlider";
import { Footer } from "./Footer";
import { Gallery } from "./Gallery";
import { Header } from "./Header";
import { QuoteForm } from "./QuoteForm";
import { ScrollReveal } from "./ScrollReveal";
import { brand, featuredServices, packages, ppfTypes, trustCards } from "../site-data";

const trustBar = [
  "5-Star Rated",
  "7+ Years of Experience",
  "Premium Materials",
  "Professional Installation",
  "UAE-Wide Service",
];

const process = [
  ["Tell Us About Your Vehicle", "Share the vehicle make, model, year and required service."],
  ["Vehicle Inspection", "The team inspects the vehicle and recommends the most suitable service."],
  ["Professional Service", "The vehicle is carefully prepared, serviced and finished by experienced technicians."],
  ["Final Quality Inspection", "Every completed vehicle undergoes a detailed inspection before delivery."],
];

export function HomePage() {
  return (
    <main>
      <Header />
      <ScrollReveal />

      <section className="hero" id="home">
        <img className="hero-bg" src="/assets/hero.webp" alt="Luxury SUV receiving PPF installation in a premium dark workshop" />
        <div className="hero-overlay" />
        <div className="section-inner hero-content">
          <div className="hero-copy reveal">
            <span className="section-kicker">Phantom PPF & Auto Care</span>
            <h1>Complete Car Protection, Styling & Maintenance</h1>
            <p>
              Premium PPF, ceramic coating, tinting, painting, detailing and oil change
              services-all professionally delivered under one roof in the UAE.
            </p>
            <div className="hero-actions">
              <Link className="btn btn-primary" href="#quote">
                Get a Free Quote
                <ArrowRight size={18} />
              </Link>
              <a className="btn btn-outline" href={brand.whatsappQuote}>
                <MessageCircle size={18} />
                Chat on WhatsApp
              </a>
            </div>
            <a className="hero-brochure" href={brand.brochure} target="_blank" rel="noreferrer">
              Download Our Brochure
              <Download size={16} />
            </a>
          </div>
          <div className="trust-bar reveal">
            {trustBar.map((item) => (
              <span key={item}>
                <Star size={15} />
                {item}
              </span>
            ))}
          </div>
        </div>
      </section>

      <section className="section split-section" id="about">
        <div className="section-inner split-grid">
          <div className="copy-block reveal">
            <span className="section-kicker">Complete automotive care</span>
            <h2>More Than PPF. Complete Care for Your Car.</h2>
            <p>
              Phantom PPF & Auto Care provides professional vehicle protection, styling,
              restoration and maintenance services in the UAE.
            </p>
            <p>
              Whether you want to protect a brand-new vehicle, transform its appearance,
              restore damaged paint, improve cabin comfort or complete routine maintenance,
              Phantom provides tailored automotive solutions under one roof.
            </p>
            <Link className="btn btn-primary" href="#founder">
              Discover Phantom
              <ArrowRight size={18} />
            </Link>
          </div>
          <div className="image-stack reveal">
            <img src="/assets/ppf-installation.webp" alt="Paint protection film installation close-up" />
            <div className="floating-stat">
              <strong>Founder-led</strong>
              Precision detailing and care from inspection to handover.
            </div>
          </div>
        </div>
      </section>

      <section className="section dark-section" id="services">
        <div className="section-inner">
          <div className="section-heading reveal">
            <span className="section-kicker">Main services</span>
            <h2>Everything Your Car Needs Under One Roof</h2>
          </div>
          <div className="service-grid">
            {featuredServices.map((service) => (
              <article className="service-card reveal" key={service.slug}>
                <img src={service.image} alt={service.alt} />
                <div>
                  <h3>{service.title}</h3>
                  <p>{service.intro}</p>
                  <ul>
                    {service.options.slice(0, 3).map((item) => (
                      <li key={item}>
                        <CheckCircle2 size={15} />
                        {item}
                      </li>
                    ))}
                  </ul>
                  <Link className="text-link" href={`/services/${service.slug}`}>
                    {service.slug === "oil-change" ? "Book Oil Change" : `Explore ${service.navLabel}`}
                    <ArrowRight size={16} />
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section ppf-section" id="ppf">
        <div className="section-inner">
          <div className="section-heading reveal">
            <span className="section-kicker">Paint protection film</span>
            <h2>Choose the Perfect PPF for Your Car</h2>
            <p>
              Protect your vehicle while maintaining or transforming its appearance with
              professionally installed paint protection film.
            </p>
          </div>
          <div className="ppf-grid">
            {ppfTypes.map((type) => (
              <article className="finish-card reveal" key={type.title}>
                <img src={type.image} alt={`${type.title} vehicle finish`} />
                <div>
                  <h3>{type.title}</h3>
                  <p>{type.text}</p>
                  <Link className="text-link" href={type.href}>
                    {type.button}
                    <ArrowRight size={16} />
                  </Link>
                </div>
              </article>
            ))}
          </div>
          <div className="slider-shell reveal">
            <div>
              <span className="section-kicker">Interactive finish preview</span>
              <h3>See the surface change before you commit.</h3>
              <p>
                Use the slider to compare a treated, polished look with a darker untreated
                surface. Final results depend on the vehicle condition and selected service.
              </p>
            </div>
            <BeforeAfterSlider />
          </div>
        </div>
      </section>

      <section className="section founder-section" id="founder">
        <div className="section-inner founder-grid">
          <div className="founder-image reveal">
            <img src="/assets/founder-mahid.webp" alt="Mahid, founder of Phantom PPF" />
          </div>
          <div className="copy-block reveal">
            <span className="section-kicker">Founder and CEO</span>
            <h2>Meet Mahid</h2>
            <p>
              With over a decade of experience in prestigious UAE automotive workshops,
              Mahid founded Phantom PPF with one clear mission: to
              elevate vehicle protection into an art form.
            </p>
            <p>
              Trusted by high-profile clients and known for his obsession with invisible
              edges, Mahid personally oversees every project that enters the Phantom studio.
            </p>
            <p>
              His approach combines technical expertise, premium materials and uncompromising
              attention to detail to ensure every vehicle receives exceptional care.
            </p>
            <div className="signature">Mahid - Founder, Phantom PPF</div>
            <Link className="btn btn-outline" href="#contact">
              Meet the Phantom Team
            </Link>
          </div>
        </div>
      </section>

      <section className="section trust-section">
        <div className="section-inner">
          <div className="section-heading reveal">
            <span className="section-kicker">Why choose Phantom PPF</span>
            <h2>Precision You Can See. Protection You Can Trust.</h2>
          </div>
          <div className="trust-grid">
            {trustCards.map(([title, text], index) => (
              <article className="trust-card reveal" key={title}>
                {index % 3 === 0 ? <ShieldCheck /> : index % 3 === 1 ? <Sparkles /> : <Wrench />}
                <h3>{title}</h3>
                <p>{text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section dark-section" id="gallery">
        <div className="section-inner">
          <div className="section-heading reveal">
            <span className="section-kicker">Project gallery</span>
            <h2>See the Phantom Difference</h2>
            <p>
              Browse protection, styling and maintenance project briefs for luxury cars,
              SUVs, sports vehicles, Chinese vehicles and everyday drivers.
            </p>
          </div>
          <Gallery />
        </div>
      </section>

      <section className="section reviews-section" id="reviews">
        <div className="section-inner reviews-grid">
          <div className="copy-block reveal">
            <span className="section-kicker">Customer proof</span>
            <h2>Trusted by Car Owners Across the UAE</h2>
            <p>
              The Phantom public listing shows strong online rating proof. This website avoids
              invented customer names or fabricated review quotes; add verified screenshots
              here whenever the latest review exports are available.
            </p>
            <div className="rating-card">
              <div className="stars" aria-label="Five star rating">
                {Array.from({ length: 5 }).map((_, index) => (
                  <Star key={index} size={20} fill="currentColor" />
                ))}
              </div>
              <strong>4.9 online rating profile</strong>
              <span>117 public online ratings observed July 2026</span>
            </div>
            <a className="btn btn-primary" href={brand.directions} target="_blank" rel="noreferrer">
              View More Customer Reviews
              <ExternalLink size={18} />
            </a>
          </div>
          <div className="proof-panel reveal">
            <img src="/assets/proof-collage.webp" alt="Phantom PPF brand, founder and automotive service proof collage" />
            <div className="testimonial-themes">
              {[
                "High-quality PPF installation",
                "Clean and professional work",
                "Excellent finishing",
                "Premium ceramic coating",
                "Professional tinting",
                "Helpful customer service",
              ].map((theme) => (
                <span key={theme}>{theme}</span>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="section packages-section" id="packages">
        <div className="section-inner">
          <div className="section-heading reveal">
            <span className="section-kicker">Featured packages</span>
            <h2>Protection Packages Designed Around Your Car</h2>
          </div>
          <div className="package-grid">
            {packages.map((pack) => (
              <article className="package-card reveal" key={pack.title}>
                <h3>{pack.title}</h3>
                <p>{pack.text}</p>
                <ul>
                  {pack.items.map((item) => (
                    <li key={item}>
                      <BadgeCheck size={16} />
                      {item}
                    </li>
                  ))}
                </ul>
                <Link className="btn btn-outline" href="#quote">
                  {pack.button}
                </Link>
              </article>
            ))}
          </div>
          <p className="disclaimer reveal">
            Final package pricing depends on the vehicle model, size, paint condition,
            selected materials and required services.
          </p>
        </div>
      </section>

      <section className="section process-section">
        <div className="section-inner">
          <div className="section-heading reveal">
            <span className="section-kicker">Service process</span>
            <h2>Professional Car Care Made Simple</h2>
          </div>
          <div className="timeline">
            {process.map(([title, text], index) => (
              <article className="timeline-step reveal" key={title}>
                <span>{String(index + 1).padStart(2, "0")}</span>
                <h3>{title}</h3>
                <p>{text}</p>
              </article>
            ))}
          </div>
          <div className="center-actions reveal">
            <Link className="btn btn-primary" href="#quote">
              <CalendarCheck size={18} />
              Book a Vehicle Inspection
            </Link>
          </div>
        </div>
      </section>

      <section className="section trust-banner">
        <div className="section-inner banner-grid">
          <div className="reveal">
            <span className="section-kicker">Warranty portal</span>
            <h2>Check Your Phantom PPF Warranty</h2>
            <p>
              Already protected your vehicle with Phantom PPF? Access the warranty portal
              to review your coverage and warranty details.
            </p>
          </div>
          <a className="btn btn-primary reveal" href={brand.warranty} target="_blank" rel="noreferrer">
            Check Warranty Details
            <ExternalLink size={18} />
          </a>
        </div>
      </section>

      <section className="section brochure-section">
        <div className="section-inner brochure-card reveal">
          <div>
            <span className="section-kicker">Service brochure</span>
            <h2>Explore Phantom Services and Protection Options</h2>
            <p>
              Download the Phantom PPF brochure to explore automotive protection, styling
              and maintenance services.
            </p>
          </div>
          <a className="btn btn-outline" href={brand.brochure} target="_blank" rel="noreferrer">
            <Download size={18} />
            Download Brochure
          </a>
        </div>
      </section>

      <section className="section quote-section">
        <div className="section-inner">
          <QuoteForm />
        </div>
      </section>

      <section className="section contact-section" id="contact">
        <div className="section-inner contact-grid">
          <div className="contact-card reveal">
            <span className="section-kicker">Visit Phantom PPF</span>
            <h2>Visit Phantom PPF</h2>
            <ul className="contact-details">
              <li>
                <Phone size={18} />
                <a href={brand.phoneHref}>{brand.phoneDisplay}</a>
              </li>
              <li>
                <Mail size={18} />
                <a href={brand.emailHref}>{brand.email}</a>
              </li>
              <li>
                <Clock size={18} />
                {brand.hours}
              </li>
              <li>
                <MapPin size={18} />
                Service area: {brand.area}
              </li>
            </ul>
            <div className="form-actions">
              <a className="btn btn-primary" href={brand.phoneHref}>
                Call Now
              </a>
              <a className="btn btn-outline" href={brand.whatsappQuote}>
                WhatsApp Us
              </a>
              <a className="btn btn-outline" href={brand.directions} target="_blank" rel="noreferrer">
                Get Directions
              </a>
            </div>
          </div>
          <div className="map-card reveal">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3611.9076463563656!2d55.24091577102599!3d25.138812984908697!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5f5df7b6c4c667%3A0x72ee7640e6decd2!2sPhantom%20Ppf!5e0!3m2!1sen!2sae!4v1776426966226!5m2!1sen!2sae"
              width="600"
              height="450"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Phantom PPF Google Maps location"
            />
          </div>
        </div>
      </section>

      <section className="final-cta">
        <img src="/assets/hero.webp" alt="Premium luxury car receiving Phantom PPF treatment" />
        <div className="final-overlay" />
        <div className="section-inner final-content reveal">
          <Car size={34} />
          <h2>Your Car Deserves the Phantom Treatment</h2>
          <p>
            Protect, enhance and maintain your vehicle with professional automotive
            services tailored to your car.
          </p>
          <div className="hero-actions">
            <Link className="btn btn-primary" href="#quote">
              Get a Free Quote
            </Link>
            <a className="btn btn-outline" href={brand.whatsappQuote}>
              Chat on WhatsApp
            </a>
            <a className="btn btn-outline" href={brand.phoneHref}>
              Call Now
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
