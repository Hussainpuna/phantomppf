import type { Metadata } from "next";
import Link from "next/link";
import { Footer } from "../components/Footer";
import { Header } from "../components/Header";
import { ScrollReveal } from "../components/ScrollReveal";

export const metadata: Metadata = {
  title: "Privacy Policy | Phantom PPF & Auto Care",
  description:
    "Privacy policy for Phantom PPF & Auto Care enquiries, quotation forms and customer contact details.",
  alternates: { canonical: "/privacy-policy" },
};

export default function Page() {
  return (
    <main>
      <Header />
      <ScrollReveal />
      <section className="plain-hero">
        <div className="section-inner reveal">
          <nav className="breadcrumbs" aria-label="Breadcrumb">
            <Link href="/">Home</Link>
            <span>/</span>
            <strong>Privacy Policy</strong>
          </nav>
          <span className="section-kicker">Website policy</span>
          <h1>Privacy Policy</h1>
          <p>
            Phantom PPF & Auto Care uses enquiry information to respond to quotations,
            bookings and service support requests.
          </p>
        </div>
      </section>
      <section className="section">
        <div className="section-inner narrow-content">
          <h2>Information Collected</h2>
          <p>
            Enquiry forms may collect name, phone number, WhatsApp number, vehicle details,
            preferred date, uploaded vehicle images and message content.
          </p>
          <h2>How Information Is Used</h2>
          <p>
            Information is used to contact you, prepare a quotation, recommend services and
            support workshop booking or warranty enquiries.
          </p>
          <h2>Third-Party Links</h2>
          <p>
            This website links to WhatsApp, Google Maps, Google Drive, Instagram, Facebook
            and the Phantom warranty portal. Those services have their own privacy practices.
          </p>
          <h2>Contact</h2>
          <p>For privacy questions, contact Phantom through the phone or email listed on the website.</p>
        </div>
      </section>
      <Footer />
    </main>
  );
}
