import Link from "next/link";
import {
  ArrowRight,
  CalendarCheck,
  CheckCircle2,
  MessageCircle,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import { brand, findService, Service } from "../site-data";
import { BeforeAfterSlider } from "./BeforeAfterSlider";
import { Footer } from "./Footer";
import { Header } from "./Header";
import { QuoteForm } from "./QuoteForm";
import { ScrollReveal } from "./ScrollReveal";

const colourFinishes = [
  "Gloss black",
  "Satin charcoal",
  "Crimson red",
  "Metallic grey",
  "Pearl white",
  "Satin blue",
  "Special order finish",
];

export function ServicePage({ service }: { service: Service }) {
  const relatedServices = service.related.map(findService).filter(Boolean) as Service[];

  return (
    <main>
      <Header />
      <ScrollReveal />
      <section className="service-hero">
        <img src={service.image} alt={service.alt} />
        <div className="hero-overlay" />
        <div className="section-inner service-hero-content reveal">
          <nav className="breadcrumbs" aria-label="Breadcrumb">
            <Link href="/">Home</Link>
            <span>/</span>
            <Link href="/#services">Services</Link>
            <span>/</span>
            <strong>{service.navLabel}</strong>
          </nav>
          <span className="section-kicker">{service.eyebrow}</span>
          <h1>{service.h1}</h1>
          <p>{service.intro}</p>
          <div className="hero-actions">
            <Link className="btn btn-primary" href="#quote">
              Request a Quote
              <ArrowRight size={18} />
            </Link>
            <a className="btn btn-outline" href={brand.whatsappQuote}>
              <MessageCircle size={18} />
              WhatsApp Quotation
            </a>
          </div>
        </div>
      </section>

      <section className="section service-intro">
        <div className="section-inner service-layout">
          <aside className="service-sidebar reveal">
            <h2>Quick Service Facts</h2>
            <p>Main focus keyword: {service.keyword}</p>
            <a className="btn btn-primary" href={brand.whatsappQuote}>
              WhatsApp Phantom
            </a>
            <a className="btn btn-outline" href={brand.phoneHref}>
              Call {brand.phoneDisplay}
            </a>
          </aside>

          <div className="service-content">
            <section className="content-panel reveal">
              <span className="section-kicker">Introduction</span>
              <h2>{service.title} at Phantom PPF</h2>
              <p>{service.intro}</p>
              {service.slug === "paint-protection-film" ? (
                <p>
                  Phantom offers glossy, matte and colour PPF, plus full-body,
                  front-end and custom-panel coverage. PPF is a physical film layer,
                  while ceramic coating is a liquid-applied surface designed for gloss,
                  hydrophobic behavior and easier cleaning.
                </p>
              ) : null}
              {service.slug === "window-tinting" ? (
                <p>
                  Tint selection must comply with current UAE regulations. Phantom can
                  guide suitable shade and film options during consultation.
                </p>
              ) : null}
              {service.slug === "oil-change" ? (
                <p>
                  The correct oil-change interval depends on the vehicle, engine,
                  manufacturer recommendation, oil type and driving conditions.
                </p>
              ) : null}
            </section>

            <section className="content-panel reveal">
              <h2>Main Benefits</h2>
              <div className="benefit-grid">
                {service.benefits.map((benefit) => (
                  <div key={benefit}>
                    <ShieldCheck size={20} />
                    <span>{benefit}</span>
                  </div>
                ))}
              </div>
            </section>

            <section className="content-panel reveal">
              <h2>Available Options</h2>
              <div className="option-grid">
                {service.options.map((option) => (
                  <span key={option}>
                    <CheckCircle2 size={16} />
                    {option}
                  </span>
                ))}
              </div>
              {service.slug === "colour-ppf" ? (
                <div className="colour-catalogue">
                  <h3>Colour and Finish Catalogue</h3>
                  <p>
                    Select a finish family and request availability from the Phantom team.
                  </p>
                  <div className="swatch-grid">
                    {colourFinishes.map((finish, index) => (
                      <a
                        key={finish}
                        href={brand.whatsappQuote}
                        className={`swatch swatch-${index + 1}`}
                      >
                        <span />
                        {finish}
                      </a>
                    ))}
                  </div>
                </div>
              ) : null}
            </section>

            <section className="content-panel reveal">
              <h2>Service Process</h2>
              <div className="mini-timeline">
                {service.process.map((step, index) => (
                  <div key={step}>
                    <span>{index + 1}</span>
                    <p>{step}</p>
                  </div>
                ))}
              </div>
            </section>

            <section className="content-panel reveal">
              <h2>Suitable Vehicles</h2>
              <div className="vehicle-tags">
                {service.suitable.map((item) => (
                  <span key={item}>{item}</span>
                ))}
              </div>
            </section>

            <section className="content-panel reveal">
              <h2>Before-and-After Gallery</h2>
              <BeforeAfterSlider />
            </section>

            <section className="content-panel reveal">
              <h2>Genuine Feedback Themes</h2>
              <p>
                This page does not publish invented reviews. Add verified customer screenshots
                here when exporting the latest review assets.
              </p>
              <div className="feedback-grid">
                {[
                  "Clean installation",
                  "Helpful consultation",
                  "Premium finish",
                  "Professional workshop",
                ].map((item) => (
                  <span key={item}>
                    <Sparkles size={16} />
                    {item}
                  </span>
                ))}
              </div>
            </section>

            <section className="content-panel faq-panel reveal">
              <h2>Frequently Asked Questions</h2>
              {service.faqs.map((faq) => (
                <details key={faq.question}>
                  <summary>{faq.question}</summary>
                  <p>{faq.answer}</p>
                </details>
              ))}
            </section>

            <section className="content-panel reveal">
              <h2>Related Services</h2>
              <div className="related-grid">
                {relatedServices.map((item) => (
                  <Link key={item.slug} href={`/services/${item.slug}`}>
                    <img src={item.image} alt={item.alt} />
                    <span>{item.navLabel}</span>
                  </Link>
                ))}
              </div>
            </section>

            <QuoteForm compact />
          </div>
        </div>
      </section>

      <section className="final-cta service-final">
        <img src={service.image} alt={service.alt} />
        <div className="final-overlay" />
        <div className="section-inner final-content reveal">
          <CalendarCheck size={34} />
          <h2>Ready to Book {service.navLabel}?</h2>
          <p>
            Share your vehicle details and the Phantom team will recommend the best
            approach for your car.
          </p>
          <div className="hero-actions">
            <Link className="btn btn-primary" href="#quote">
              Get a Free Quote
            </Link>
            <a className="btn btn-outline" href={brand.whatsappQuote}>
              Chat on WhatsApp
            </a>
          </div>
        </div>
      </section>
      <Footer />
    </main>
  );
}
