import type { Metadata } from "next";
import Link from "next/link";
import { MessageCircle } from "lucide-react";
import { Footer } from "../components/Footer";
import { Header } from "../components/Header";
import { ScrollReveal } from "../components/ScrollReveal";
import { brand } from "../site-data";

export const metadata: Metadata = {
  title: "PPF Aftercare Guide Dubai | Phantom PPF",
  description:
    "General paint protection film aftercare guidance for Phantom PPF customers in Dubai and the UAE.",
  alternates: { canonical: "/ppf-aftercare-guide" },
};

export default function Page() {
  return (
    <main>
      <Header />
      <ScrollReveal />
      <section className="plain-hero">
        <div className="section-inner reveal">
          <nav className="breadcrumbs" aria-label="Breadcrumb">
            <Link href="/">Home</Link>
            <span>/</span>
            <strong>PPF Aftercare Guide</strong>
          </nav>
          <span className="section-kicker">Paint protection care</span>
          <h1>PPF Aftercare Guide</h1>
          <p>
            A simple care guide for customers after paint protection film installation.
            Always follow the specific advice provided at handover.
          </p>
          <a className="btn btn-primary" href={brand.whatsappQuote}>
            <MessageCircle size={18} />
            Ask Phantom About Aftercare
          </a>
        </div>
      </section>
      <section className="section">
        <div className="section-inner narrow-content">
          <h2>First Days After Installation</h2>
          <p>
            Allow the film to settle. Avoid picking at edges, aggressive wiping or pressure
            washing close to film edges during the early settling period.
          </p>
          <h2>Washing</h2>
          <p>
            Use gentle automotive wash products, clean microfiber towels and a controlled
            wash process. Avoid harsh chemicals and abrasive pads.
          </p>
          <h2>Edges and Inspection</h2>
          <p>
            Inspect edges periodically. If you notice lifting, dirt build-up near an edge or
            film damage, contact Phantom before attempting repair yourself.
          </p>
          <h2>Combining With Ceramic Coating</h2>
          <p>
            Ceramic coating can be used with compatible PPF to improve water behavior and
            cleaning ease. Phantom can advise the correct timing and product approach.
          </p>
        </div>
      </section>
      <Footer />
    </main>
  );
}
