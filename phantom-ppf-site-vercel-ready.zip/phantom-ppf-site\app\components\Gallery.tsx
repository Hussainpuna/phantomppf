"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { ArrowUpRight, X } from "lucide-react";
import { projects } from "../site-data";

const filters = [
  "All Projects",
  "Glossy PPF",
  "Matte PPF",
  "Colour PPF",
  "Ceramic Coating",
  "Window Tinting",
  "Car Painting",
  "Detailing",
];

export function Gallery() {
  const [filter, setFilter] = useState("All Projects");
  const [lightbox, setLightbox] = useState<(typeof projects)[number] | null>(null);

  const filtered = useMemo(() => {
    if (filter === "All Projects") return projects;
    return projects.filter((item) => item.category === filter);
  }, [filter]);

  return (
    <div className="gallery-wrap">
      <div className="filter-tabs" role="tablist" aria-label="Project filters">
        {filters.map((item) => (
          <button
            key={item}
            type="button"
            className={filter === item ? "active" : ""}
            onClick={() => setFilter(item)}
          >
            {item}
          </button>
        ))}
      </div>

      <div className="project-grid">
        {filtered.map((project) => (
          <article className="project-card reveal" key={project.slug}>
            <button className="image-button" type="button" onClick={() => setLightbox(project)}>
              <img src={project.image} alt={`${project.title} visual`} />
            </button>
            <div className="project-body">
              <span>{project.service}</span>
              <h3>{project.vehicle}</h3>
              <p>{project.text}</p>
              <dl>
                <div>
                  <dt>Finish</dt>
                  <dd>{project.finish}</dd>
                </div>
                <div>
                  <dt>Service</dt>
                  <dd>{project.service}</dd>
                </div>
              </dl>
              <Link className="text-link" href={`/projects/${project.slug}`}>
                View Project
                <ArrowUpRight size={16} />
              </Link>
            </div>
          </article>
        ))}
      </div>

      {lightbox ? (
        <div className="lightbox" role="dialog" aria-modal="true" aria-label={lightbox.title}>
          <button className="icon-btn close-lightbox" type="button" onClick={() => setLightbox(null)}>
            <X size={22} />
          </button>
          <img src={lightbox.image} alt={lightbox.title} />
          <div>
            <h3>{lightbox.title}</h3>
            <p>{lightbox.text}</p>
          </div>
        </div>
      ) : null}
    </div>
  );
}
