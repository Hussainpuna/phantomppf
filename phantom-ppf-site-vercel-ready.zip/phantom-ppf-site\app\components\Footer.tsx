import Link from "next/link";
import { Camera, Mail, MapPin, Phone, Share2 } from "lucide-react";
import { brand } from "../site-data";

const quickLinks = [
  ["Home", "/"],
  ["About", "/#about"],
  ["Services", "/#services"],
  ["Gallery", "/#gallery"],
  ["Reviews", "/#reviews"],
  ["Warranty", "/warranty"],
  ["Contact", "/#contact"],
];

const footerServices = [
  ["Paint Protection Film", "/services/paint-protection-film"],
  ["Glossy PPF", "/services/glossy-ppf"],
  ["Matte PPF", "/services/matte-ppf"],
  ["Colour PPF", "/services/colour-ppf"],
  ["Ceramic Coating", "/services/ceramic-coating"],
  ["Window Tinting", "/services/window-tinting"],
  ["Car Painting", "/services/car-painting"],
  ["Car Detailing", "/services/car-detailing"],
  ["Oil Change", "/services/oil-change"],
];

export function Footer() {
  return (
    <footer className="footer">
      <div className="section-inner footer-grid">
        <div>
          <img className="footer-logo" src="/assets/logo.webp" alt="Phantom PPF & Auto Care logo" />
          <p>
            Professional vehicle protection, styling, restoration and maintenance services in
            the UAE.
          </p>
          <div className="social-row">
            <a href={brand.instagram} target="_blank" rel="noreferrer" aria-label="Instagram">
              <Camera size={18} />
            </a>
            <a href={brand.facebook} target="_blank" rel="noreferrer" aria-label="Facebook">
              <Share2 size={18} />
            </a>
          </div>
        </div>

        <div>
          <h2>Quick Links</h2>
          <ul>
            {quickLinks.map(([label, href]) => (
              <li key={label}>
                <Link href={href}>{label}</Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h2>Main Services</h2>
          <ul>
            {footerServices.map(([label, href]) => (
              <li key={label}>
                <Link href={href}>{label}</Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h2>Contact</h2>
          <ul className="contact-list">
            <li>
              <Phone size={16} />
              <a href={brand.phoneHref}>{brand.phoneDisplay}</a>
            </li>
            <li>
              <Mail size={16} />
              <a href={brand.emailHref}>{brand.email}</a>
            </li>
            <li>
              <MapPin size={16} />
              <span>Every day: 9:00 AM-9:00 PM</span>
            </li>
            <li>
              <MapPin size={16} />
              <span>Service area: UAE</span>
            </li>
          </ul>
          <div className="footer-extra">
            <a href={brand.brochure} target="_blank" rel="noreferrer">
              Download Brochure
            </a>
            <a href={brand.warranty} target="_blank" rel="noreferrer">
              Check Warranty
            </a>
            <Link href="/privacy-policy">Privacy Policy</Link>
            <Link href="/terms-and-conditions">Terms and Conditions</Link>
            <Link href="/ppf-aftercare-guide">PPF Aftercare Guide</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
