"use client";

import { useState } from "react";

export function BeforeAfterSlider() {
  const [value, setValue] = useState(54);

  return (
    <div className="before-after" aria-label="Before and after paint protection film comparison">
      <div className="before-after-img after">
        <img src="/assets/ppf-installation.webp" alt="After PPF installation with glossy protected finish" />
      </div>
      <div className="before-after-img before" style={{ width: `${value}%` }}>
        <img src="/assets/car-detailing.webp" alt="Before detailing and protection showing untreated paint" />
      </div>
      <div className="slider-line" style={{ left: `${value}%` }} />
      <span className="comparison-label before-label">Before</span>
      <span className="comparison-label after-label">After</span>
      <input
        type="range"
        min="18"
        max="82"
        value={value}
        aria-label="Move before and after slider"
        onChange={(event) => setValue(Number(event.target.value))}
      />
    </div>
  );
}
