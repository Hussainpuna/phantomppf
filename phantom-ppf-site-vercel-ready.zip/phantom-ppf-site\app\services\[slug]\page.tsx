import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ServicePage } from "@/app/components/ServicePage";
import { brand, findService, services } from "@/app/site-data";

type PageProps = {
  params: Promise<{ slug: string }>;
};

export function generateStaticParams() {
  return services.map((service) => ({ slug: service.slug }));
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const service = findService(slug);
  if (!service) return {};

  return {
    title: service.seoTitle,
    description: service.metaDescription,
    alternates: { canonical: `/services/${service.slug}` },
    openGraph: {
      title: service.seoTitle,
      description: service.metaDescription,
      images: [service.image],
    },
  };
}

export default async function Page({ params }: PageProps) {
  const { slug } = await params;
  const service = findService(slug);
  if (!service) notFound();

  const serviceSchema = {
    "@context": "https://schema.org",
    "@type": "Service",
    name: service.title,
    description: service.metaDescription,
    areaServed: "Dubai, UAE",
    provider: {
      "@type": "AutomotiveBusiness",
      name: brand.name,
      telephone: brand.phoneDisplay,
      url: brand.siteUrl,
    },
    serviceType: service.title,
  };

  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: service.faqs.map((faq) => ({
      "@type": "Question",
      name: faq.question,
      acceptedAnswer: {
        "@type": "Answer",
        text: faq.answer,
      },
    })),
  };

  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: brand.siteUrl },
      {
        "@type": "ListItem",
        position: 2,
        name: "Services",
        item: `${brand.siteUrl}/#services`,
      },
      {
        "@type": "ListItem",
        position: 3,
        name: service.navLabel,
        item: `${brand.siteUrl}/services/${service.slug}`,
      },
    ],
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(serviceSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }}
      />
      <ServicePage service={service} />
    </>
  );
}
