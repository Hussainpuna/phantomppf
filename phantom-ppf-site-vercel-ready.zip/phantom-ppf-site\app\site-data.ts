export const brand = {
  name: "Phantom PPF & Auto Care",
  shortName: "Phantom PPF",
  positioning: "Complete Car Protection, Styling and Maintenance in the UAE",
  phoneDisplay: "+971 52 365 6678",
  phoneHref: "tel:+971523656678",
  whatsapp: "https://wa.me/971523656678",
  whatsappQuote:
    "https://wa.me/971523656678?text=Hello%20Phantom%20PPF%2C%20I%20would%20like%20to%20request%20a%20quotation%20for%20my%20vehicle.%0AVehicle%20make%20and%20model%3A%0AVehicle%20year%3A%0ARequired%20service%3A",
  email: "ahadbk@gmail.com",
  emailHref: "mailto:ahadbk@gmail.com",
  hours: "Every day, 9:00 AM to 9:00 PM",
  area: "UAE",
  instagram: "https://www.instagram.com/phantom_ppf_/",
  facebook: "https://www.facebook.com/profile.php?id=100089555174705",
  brochure:
    "https://drive.google.com/file/d/13dgCS21KNzWUR4JuBiBlUIESeNh2Gf2A/view?usp=drive_link",
  warranty: "https://ppfwarrant-gy6ntr4v.manus.space/",
  directions:
    "https://www.google.com/maps/search/?api=1&query=Phantom%20Ppf%20Dubai",
  siteUrl: "https://www.ppfphantom.com",
};

export const navItems = [
  { label: "Home", href: "/" },
  { label: "About Us", href: "/#about" },
  { label: "Services", href: "/#services" },
  { label: "Paint Protection Film", href: "/services/paint-protection-film" },
  { label: "Ceramic Coating", href: "/services/ceramic-coating" },
  { label: "Window Tinting", href: "/services/window-tinting" },
  { label: "Car Painting", href: "/services/car-painting" },
  { label: "Car Detailing", href: "/services/car-detailing" },
  { label: "Oil Change", href: "/services/oil-change" },
  { label: "Packages", href: "/#packages" },
  { label: "Gallery", href: "/#gallery" },
  { label: "Reviews", href: "/#reviews" },
  { label: "Contact", href: "/#contact" },
];

export type Service = {
  slug: string;
  navLabel: string;
  title: string;
  seoTitle: string;
  metaDescription: string;
  h1: string;
  eyebrow: string;
  image: string;
  alt: string;
  keyword: string;
  intro: string;
  benefits: string[];
  options: string[];
  process: string[];
  suitable: string[];
  faqs: { question: string; answer: string }[];
  related: string[];
};

export const services: Service[] = [
  {
    slug: "paint-protection-film",
    navLabel: "Paint Protection Film",
    title: "Paint Protection Film",
    seoTitle: "Paint Protection Film Dubai | Professional Car PPF Installation",
    metaDescription:
      "Professional paint protection film in Dubai for full-body, front-end, glossy, matte and colour PPF coverage by Phantom PPF & Auto Care.",
    h1: "Professional Paint Protection Film in Dubai",
    eyebrow: "Premium PPF installation",
    image: "/assets/ppf-installation.webp",
    alt: "Technician applying clear paint protection film to a glossy car fender",
    keyword: "paint protection film Dubai",
    intro:
      "PPF is a clear or finished protective film installed over painted panels to help shield the vehicle from stone chips, minor scratches, road debris and daily environmental exposure.",
    benefits: [
      "Helps protect original paint from road debris and light abrasion",
      "Available in glossy, matte, satin and colour finishes",
      "Can be installed on the full body, front end or selected panels",
      "Supports stronger resale appeal by preserving factory paint",
      "Pairs well with ceramic coating for easier exterior maintenance",
    ],
    options: [
      "Glossy PPF",
      "Matte PPF",
      "Colour PPF",
      "Full-body PPF",
      "Front-end PPF",
      "Custom-panel protection",
    ],
    process: [
      "Vehicle inspection and coverage recommendation",
      "Wash, decontamination and careful surface preparation",
      "Panel-specific film application and alignment",
      "Detailed edge finishing and quality inspection",
    ],
    suitable: [
      "New luxury and sports cars",
      "SUVs and family vehicles",
      "Chinese vehicles and daily drivers",
      "Cars exposed to highway driving or harsh UAE weather",
    ],
    faqs: [
      {
        question: "What is the difference between PPF and ceramic coating?",
        answer:
          "PPF is a physical film layer for painted panels. Ceramic coating is a liquid-applied protective surface that improves gloss, water behavior and cleaning ease. Many owners combine both.",
      },
      {
        question: "Can PPF be installed only on the front of the car?",
        answer:
          "Yes. Front-end PPF can cover high-impact areas such as the bonnet, bumper, mirrors and fenders, while full-body PPF covers the major painted exterior panels.",
      },
      {
        question: "How should I maintain PPF?",
        answer:
          "Wash gently, avoid aggressive chemicals, and contact Phantom if you notice lifted edges or damage. Exact care depends on the film and installation details.",
      },
    ],
    related: ["glossy-ppf", "matte-ppf", "colour-ppf", "ceramic-coating"],
  },
  {
    slug: "glossy-ppf",
    navLabel: "Glossy PPF",
    title: "Glossy PPF",
    seoTitle: "Glossy PPF Dubai | Clear Paint Protection Film",
    metaDescription:
      "Glossy PPF installation in Dubai for clear paint protection that preserves and enhances the factory shine of your car.",
    h1: "Glossy PPF Installation in Dubai",
    eyebrow: "Clear factory-finish protection",
    image: "/assets/hero.webp",
    alt: "Glossy black luxury SUV in a premium PPF installation studio",
    keyword: "glossy PPF Dubai",
    intro:
      "Glossy PPF protects the original paint while maintaining the vehicle's factory shine. It is ideal for owners who want discreet protection without changing the car's appearance.",
    benefits: [
      "Maintains the vehicle's original glossy finish",
      "Adds a transparent protective layer over painted panels",
      "Ideal for new cars and high-value vehicles",
      "Can be installed on full-body or high-impact panels",
    ],
    options: [
      "Full-body glossy PPF",
      "Front-end glossy PPF",
      "Bonnet and bumper protection",
      "Door cup and edge protection",
    ],
    process: [
      "Paint condition inspection",
      "Surface cleaning and preparation",
      "Clear film installation",
      "Final gloss and edge inspection",
    ],
    suitable: [
      "Luxury sedans",
      "Sports cars",
      "New SUVs",
      "Daily cars with factory paint worth preserving",
    ],
    faqs: [
      {
        question: "Will glossy PPF change the car colour?",
        answer:
          "Glossy PPF is designed to be clear, so it keeps the factory colour visible while adding protection.",
      },
      {
        question: "Can glossy PPF be combined with ceramic coating?",
        answer:
          "Yes. Ceramic coating can be applied over compatible PPF to improve water behavior and cleaning ease.",
      },
    ],
    related: ["paint-protection-film", "matte-ppf", "colour-ppf"],
  },
  {
    slug: "matte-ppf",
    navLabel: "Matte PPF",
    title: "Matte PPF",
    seoTitle: "Matte PPF Dubai | Satin and Stealth PPF Installation",
    metaDescription:
      "Matte and satin PPF installation in Dubai for a premium stealth finish with paint protection by Phantom PPF & Auto Care.",
    h1: "Matte and Satin PPF in Dubai",
    eyebrow: "Stealth styling with protection",
    image: "/assets/matte-ppf.webp",
    alt: "Luxury SUV with satin matte charcoal PPF finish in a dark studio",
    keyword: "matte PPF Dubai",
    intro:
      "Matte PPF can transform glossy paint into a satin or stealth appearance while protecting the original paint underneath.",
    benefits: [
      "Creates a premium matte or satin look",
      "Protects the original paint below the film",
      "Ideal for visual transformation without repainting",
      "Works for full-body and selected-panel styling",
    ],
    options: [
      "Satin full-body PPF",
      "Stealth matte PPF",
      "Matte accents",
      "Panel-by-panel finish matching",
    ],
    process: [
      "Finish consultation",
      "Panel preparation",
      "Film alignment and installation",
      "Satin finish quality check",
    ],
    suitable: [
      "Luxury SUVs",
      "Performance coupes",
      "Brand-new vehicles",
      "Owners wanting a factory-style stealth look",
    ],
    faqs: [
      {
        question: "Can matte PPF turn a glossy car matte?",
        answer:
          "Yes. Matte or satin PPF can visually transform glossy paint while keeping the original paint protected underneath.",
      },
      {
        question: "Does matte PPF need special care?",
        answer:
          "Use matte-safe wash products and avoid polishing the matte film surface. Phantom can advise care based on the selected material.",
      },
    ],
    related: ["paint-protection-film", "glossy-ppf", "colour-ppf"],
  },
  {
    slug: "colour-ppf",
    navLabel: "Colour PPF",
    title: "Colour PPF",
    seoTitle: "Colour PPF Dubai | Coloured Paint Protection Film",
    metaDescription:
      "Colour PPF installation in Dubai for protective colour-change film, finish selection and availability requests.",
    h1: "Colour PPF Installation in Dubai",
    eyebrow: "Colour transformation plus protection",
    image: "/assets/colour-ppf.webp",
    alt: "Performance coupe with deep crimson colour PPF finish in a studio",
    keyword: "colour PPF Dubai",
    intro:
      "Colour PPF changes the appearance of a vehicle while adding a protective film layer over the paint. It differs from traditional vinyl wrapping because it is selected for both styling and painted-panel protection.",
    benefits: [
      "Transforms the vehicle appearance",
      "Adds a protective film layer over painted panels",
      "Available in gloss, satin, matte and special finishes",
      "A strong option for styling-focused UAE car owners",
    ],
    options: [
      "Gloss colour PPF",
      "Satin colour PPF",
      "Matte colour PPF",
      "Metallic finish PPF",
      "Custom availability request",
    ],
    process: [
      "Colour and finish consultation",
      "Availability confirmation",
      "Vehicle preparation",
      "Installation and finish inspection",
    ],
    suitable: [
      "Style-focused owners",
      "Sports cars",
      "SUVs",
      "Customers comparing colour PPF and vinyl wrap",
    ],
    faqs: [
      {
        question: "Is colour PPF the same as vinyl wrap?",
        answer:
          "Both can change appearance, but colour PPF is selected as a protective film solution. Vinyl wrap is primarily a styling film. Exact performance depends on the chosen material.",
      },
      {
        question: "Can I request a specific colour?",
        answer:
          "Yes. Choose a finish family and Phantom can confirm availability before booking.",
      },
    ],
    related: ["paint-protection-film", "matte-ppf", "glossy-ppf"],
  },
  {
    slug: "ceramic-coating",
    navLabel: "Ceramic Coating",
    title: "Ceramic Coating",
    seoTitle: "Ceramic Coating Dubai | Professional Car Ceramic Coating",
    metaDescription:
      "Professional ceramic coating in Dubai for gloss enhancement, hydrophobic behavior and easier vehicle maintenance.",
    h1: "Professional Ceramic Coating in Dubai",
    eyebrow: "Hydrophobic gloss enhancement",
    image: "/assets/ceramic-coating.webp",
    alt: "Ceramic coating being applied to a glossy red car hood",
    keyword: "ceramic coating Dubai",
    intro:
      "Ceramic coating enhances gloss and creates a hydrophobic surface that helps make the vehicle easier to clean and maintain.",
    benefits: [
      "Improves paint gloss and depth",
      "Creates water-beading hydrophobic behavior",
      "Helps routine washing feel easier",
      "Can be used on paint, compatible PPF, rims and glass",
      "Pairs well with paint correction before application",
    ],
    options: [
      "Paint ceramic coating",
      "PPF top coating",
      "Glass coating",
      "Rim ceramic coating",
      "Paint correction before coating",
    ],
    process: [
      "Vehicle wash and decontamination",
      "Paint inspection and correction recommendation",
      "Coating application",
      "Curing guidance and final inspection",
    ],
    suitable: [
      "New and used vehicles",
      "Cars with polished paint",
      "PPF-protected vehicles",
      "Owners who want easier maintenance",
    ],
    faqs: [
      {
        question: "Does ceramic coating stop stone chips?",
        answer:
          "No. Ceramic coating is not a physical impact film and should not be treated as stone-chip protection. PPF is the better choice for that need.",
      },
      {
        question: "Do I need paint correction first?",
        answer:
          "Paint correction may be recommended if the paint has swirl marks, oxidation or visible defects before coating.",
      },
    ],
    related: ["paint-protection-film", "car-detailing", "window-tinting"],
  },
  {
    slug: "window-tinting",
    navLabel: "Window Tinting",
    title: "Car Window Tinting",
    seoTitle: "Car Window Tinting Dubai | Heat and UV Protection Tint",
    metaDescription:
      "Professional car window tinting in Dubai for heat reduction, privacy, UV protection and glare control with UAE regulation guidance.",
    h1: "Professional Car Window Tinting in Dubai",
    eyebrow: "Heat, glare and privacy control",
    image: "/assets/window-tinting.webp",
    alt: "Technician installing dark tint film on an SUV side window",
    keyword: "car window tinting Dubai",
    intro:
      "Professional tinting improves cabin comfort, reduces glare and adds privacy while helping protect the interior from UV exposure.",
    benefits: [
      "Helps reduce heat inside the cabin",
      "Reduces glare during bright UAE driving",
      "Adds privacy",
      "Helps protect interior materials from UV exposure",
      "Installed cleanly for a factory-style finish",
    ],
    options: [
      "Heat rejection tint",
      "UV protection tint",
      "Nano ceramic tint",
      "Privacy tint",
      "Windshield strip where permitted",
    ],
    process: [
      "Tint shade consultation",
      "Glass preparation",
      "Film installation and trimming",
      "Final inspection and care guidance",
    ],
    suitable: [
      "Luxury vehicles",
      "Family SUVs",
      "Electric vehicles",
      "Daily commuters in Dubai heat",
    ],
    faqs: [
      {
        question: "Does tint need to follow UAE rules?",
        answer:
          "Yes. Tint selection must comply with current UAE regulations. Phantom can guide you during selection.",
      },
      {
        question: "How soon can I clean tinted windows?",
        answer:
          "Wait for the film to settle based on the installer's guidance before cleaning the inside glass.",
      },
    ],
    related: ["ceramic-coating", "paint-protection-film", "car-detailing"],
  },
  {
    slug: "car-painting",
    navLabel: "Car Painting",
    title: "Car Painting",
    seoTitle: "Car Painting Dubai | Full-Body and Panel Paint Repair",
    metaDescription:
      "Professional car painting and paint repair in Dubai including panel painting, bumper painting, scratch repair, colour matching and restoration.",
    h1: "Professional Car Painting and Paint Repair in Dubai",
    eyebrow: "Restoration and colour matching",
    image: "/assets/car-painting.webp",
    alt: "Technician spraying metallic grey paint on a vehicle panel in a paint booth",
    keyword: "car painting Dubai",
    intro:
      "Phantom supports paint restoration with professional colour matching, panel painting, bumper painting, scratch repair and full-body painting where suitable.",
    benefits: [
      "Restores scratched, faded or damaged paint",
      "Supports panel and bumper repair needs",
      "Colour matching for clean visual consistency",
      "Available with styling options such as rim and caliper painting",
    ],
    options: [
      "Full-body painting",
      "Panel painting",
      "Bumper painting",
      "Scratch repair",
      "Paint touch-up",
      "Rim painting",
      "Brake caliper painting",
      "Paint restoration",
    ],
    process: [
      "Paint condition inspection",
      "Repair scope and colour matching",
      "Surface preparation and painting",
      "Finishing, polish and final inspection",
    ],
    suitable: [
      "Scratched panels",
      "Faded paint",
      "Accident repair follow-up",
      "Styling updates and restoration projects",
    ],
    faqs: [
      {
        question: "Can Phantom paint only one damaged panel?",
        answer:
          "Yes. Panel painting and bumper painting can be discussed after inspection and colour matching.",
      },
      {
        question: "Can painting be combined with PPF?",
        answer:
          "Yes. After proper curing and inspection, PPF can be planned to protect repaired or refreshed paint.",
      },
    ],
    related: ["paint-protection-film", "car-detailing", "colour-ppf"],
  },
  {
    slug: "car-detailing",
    navLabel: "Car Detailing",
    title: "Car Detailing",
    seoTitle: "Car Detailing Dubai | Interior and Exterior Detailing",
    metaDescription:
      "Professional car detailing in Dubai including interior deep cleaning, exterior detailing, polishing, paint correction and headlight restoration.",
    h1: "Professional Car Detailing in Dubai",
    eyebrow: "Deep clean, polish and refresh",
    image: "/assets/car-detailing.webp",
    alt: "Detailer polishing a black car door to a mirror finish",
    keyword: "car detailing Dubai",
    intro:
      "Detailing refreshes the vehicle inside and out with deep cleaning, polishing, paint correction and finish-focused care.",
    benefits: [
      "Improves exterior gloss and paint clarity",
      "Refreshes interior surfaces",
      "Supports ceramic coating preparation",
      "Helps restore a cleaner, more premium cabin feel",
    ],
    options: [
      "Interior deep cleaning",
      "Exterior detailing",
      "Paint correction",
      "Car polishing",
      "Leather cleaning",
      "Fabric and carpet cleaning",
      "Headlight restoration",
      "Rim cleaning",
    ],
    process: [
      "Vehicle condition check",
      "Interior and exterior preparation",
      "Cleaning, correction or polishing",
      "Final finish inspection",
    ],
    suitable: [
      "Daily drivers",
      "Luxury vehicles",
      "Pre-sale refreshes",
      "Vehicles before ceramic coating",
    ],
    faqs: [
      {
        question: "Is detailing the same as washing?",
        answer:
          "No. Detailing is more thorough and can include deep cleaning, polishing and correction depending on the selected package.",
      },
      {
        question: "Can detailing remove every scratch?",
        answer:
          "Paint correction can improve many visible defects, but deeper scratches may require paint repair.",
      },
    ],
    related: ["ceramic-coating", "car-painting", "oil-change"],
  },
  {
    slug: "oil-change",
    navLabel: "Oil Change",
    title: "Oil Change and Maintenance",
    seoTitle: "Oil Change Dubai | Engine Oil and Filter Change",
    metaDescription:
      "Professional oil change in Dubai with engine oil replacement, oil filter replacement and essential vehicle checks.",
    h1: "Professional Oil Change in Dubai",
    eyebrow: "Essential maintenance made simple",
    image: "/assets/oil-change.webp",
    alt: "Technician replacing an oil filter during a clean workshop oil change",
    keyword: "oil change Dubai",
    intro:
      "Phantom supports smooth engine performance with professional engine oil replacement, oil filter replacement and essential checks.",
    benefits: [
      "Engine oil replacement",
      "Oil filter replacement",
      "Fluid-level check",
      "Visual leak inspection",
      "Tyre-pressure check",
      "Basic vehicle inspection",
      "Service reminder reset where supported",
    ],
    options: [
      "Oil and filter change",
      "Quick inspection",
      "Fluid-level check",
      "Maintenance reminder support",
    ],
    process: [
      "Confirm vehicle details and oil requirement",
      "Drain and replace engine oil",
      "Replace oil filter",
      "Check levels and inspect before handover",
    ],
    suitable: [
      "Daily vehicles",
      "SUVs",
      "Chinese vehicles",
      "Luxury and performance cars requiring careful handling",
    ],
    faqs: [
      {
        question: "How often should I change engine oil?",
        answer:
          "The correct interval depends on the vehicle, engine, manufacturer recommendation, oil type and driving conditions.",
      },
      {
        question: "Can I book oil change with detailing?",
        answer:
          "Yes. Oil change can be combined with detailing, inspection or other Phantom services.",
      },
    ],
    related: ["car-detailing", "ceramic-coating", "window-tinting"],
  },
];

export const featuredServices = services.filter((service) =>
  [
    "paint-protection-film",
    "ceramic-coating",
    "window-tinting",
    "car-painting",
    "car-detailing",
    "oil-change",
  ].includes(service.slug),
);

export const ppfTypes = [
  {
    title: "Glossy PPF",
    href: "/services/glossy-ppf",
    image: "/assets/hero.webp",
    text: "Preserve and enhance the original glossy finish with clear paint protection film.",
    button: "View Glossy PPF",
  },
  {
    title: "Matte PPF",
    href: "/services/matte-ppf",
    image: "/assets/matte-ppf.webp",
    text: "Transform glossy paint into a premium matte or satin finish while protecting the paint underneath.",
    button: "View Matte PPF",
  },
  {
    title: "Colour PPF",
    href: "/services/colour-ppf",
    image: "/assets/colour-ppf.webp",
    text: "Change the appearance of the vehicle while combining colour transformation with protection.",
    button: "View Colour PPF",
  },
  {
    title: "Full-Body PPF",
    href: "/services/paint-protection-film",
    image: "/assets/ppf-installation.webp",
    text: "Protect all major painted exterior panels for maximum vehicle coverage.",
    button: "View Full-Body PPF",
  },
];

export const packages = [
  {
    title: "New Car Protection Package",
    text: "Recommended for newly purchased vehicles.",
    items: [
      "Full-body or front-end PPF",
      "Ceramic coating",
      "Window tinting",
      "Interior protection",
      "Rim ceramic coating",
    ],
    button: "Get Package Price",
  },
  {
    title: "Complete Exterior Protection",
    text: "A focused exterior package for owners who want broad bodywork coverage.",
    items: [
      "Full-body PPF",
      "Ceramic coating",
      "Glass coating",
      "Rim protection",
      "Exterior detailing",
    ],
    button: "Request a Quote",
  },
  {
    title: "Vehicle Styling Package",
    text: "For customers who want a sharper, more distinctive vehicle look.",
    items: [
      "Matte or colour PPF",
      "Window tinting",
      "Rim painting",
      "Brake caliper painting",
      "Exterior detailing",
    ],
    button: "Transform My Car",
  },
  {
    title: "Car Refresh Package",
    text: "Bring back a cleaner, sharper feeling inside and out.",
    items: [
      "Interior detailing",
      "Exterior detailing",
      "Paint correction",
      "Headlight polishing",
      "Oil and filter change",
    ],
    button: "Refresh My Car",
  },
];

export const projects = [
  {
    slug: "full-body-glossy-ppf-for-jetour-t2-in-dubai",
    title: "Full-Body Glossy PPF for Jetour T2 in Dubai",
    vehicle: "Jetour T2",
    service: "Full-body PPF",
    finish: "Glossy clear protection",
    category: "Glossy PPF",
    image: "/assets/ppf-installation.webp",
    text: "A protection-focused SUV brief for Dubai driving, planned around broad painted-panel coverage and a clear factory-gloss finish.",
  },
  {
    slug: "matte-ppf-for-mercedes-g-class",
    title: "Matte PPF for Mercedes G-Class",
    vehicle: "Mercedes G-Class",
    service: "Matte PPF",
    finish: "Satin charcoal finish",
    category: "Matte PPF",
    image: "/assets/matte-ppf.webp",
    text: "A stealth-style SUV transformation concept showing how satin film can change the look while protecting the paint below.",
  },
  {
    slug: "colour-ppf-for-sports-coupe-in-dubai",
    title: "Colour PPF for Sports Coupe in Dubai",
    vehicle: "Sports Coupe",
    service: "Colour PPF",
    finish: "Deep crimson finish",
    category: "Colour PPF",
    image: "/assets/colour-ppf.webp",
    text: "A styling-focused colour PPF brief for owners who want a dramatic new finish with a protective film layer.",
  },
  {
    slug: "ceramic-coating-for-bmw-in-dubai",
    title: "Ceramic Coating for BMW in Dubai",
    vehicle: "BMW",
    service: "Ceramic coating",
    finish: "Hydrophobic gloss",
    category: "Ceramic Coating",
    image: "/assets/ceramic-coating.webp",
    text: "A gloss and maintenance-focused coating brief for owners who want easier cleaning and stronger paint depth.",
  },
  {
    slug: "window-tinting-for-tesla-model-3",
    title: "Window Tinting for Tesla Model 3",
    vehicle: "Tesla Model 3",
    service: "Window tinting",
    finish: "Heat rejection tint",
    category: "Window Tinting",
    image: "/assets/window-tinting.webp",
    text: "A cabin comfort brief for electric vehicle owners looking for heat control, UV protection and a cleaner exterior profile.",
  },
  {
    slug: "car-painting-for-nissan-patrol",
    title: "Car Painting for Nissan Patrol",
    vehicle: "Nissan Patrol",
    service: "Car painting",
    finish: "Panel repair and colour matching",
    category: "Car Painting",
    image: "/assets/car-painting.webp",
    text: "A restoration-focused SUV paint brief covering scratch repair, panel preparation and controlled booth refinishing.",
  },
  {
    slug: "detailing-for-luxury-suv-in-dubai",
    title: "Luxury SUV Detailing in Dubai",
    vehicle: "Luxury SUV",
    service: "Detailing",
    finish: "Polished gloss refresh",
    category: "Detailing",
    image: "/assets/car-detailing.webp",
    text: "A premium detailing brief for interior freshness, exterior polishing and finish refinement before handover.",
  },
];

export const trustCards = [
  ["Complete Automotive Care", "Protection, styling, restoration and maintenance services from one professional team."],
  ["Precision Installation", "Careful surface preparation, accurate application and detailed finishing."],
  ["Invisible Edge Finishing", "PPF installations designed for clean, discreet and professional edges."],
  ["Premium Materials", "Quality automotive films, coatings, paints and maintenance products."],
  ["Vehicle-Specific Solutions", "Recommendations tailored to the vehicle, usage, condition and customer budget."],
  ["Personally Supervised Projects", "Projects are monitored by the founder and experienced workshop specialists."],
];

export const serviceOptions = [
  "Glossy PPF",
  "Matte PPF",
  "Colour PPF",
  "Full-Body PPF",
  "Front-End PPF",
  "Ceramic Coating",
  "Window Tinting",
  "Car Painting",
  "Scratch Repair",
  "Car Detailing",
  "Paint Correction",
  "Oil Change",
  "Other",
];

export const findService = (slug: string) =>
  services.find((service) => service.slug === slug);
