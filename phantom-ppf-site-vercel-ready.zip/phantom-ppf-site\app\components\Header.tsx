"use client";

import Link from "next/link";
import { useState } from "react";
import { Download, Menu, MessageCircle, Phone, X } from "lucide-react";
import { brand, navItems } from "../site-data";

export function Header() {
  const [open, setOpen] = useState(false);

  return (
    <>
      <header className="site-header">
        <Link href="/" className="logo-link" aria-label="Phantom PPF home">
          <img src="/assets/logo.webp" alt="Phantom PPF & Auto Care logo" />
        </Link>

        <nav className="desktop-nav" aria-label="Main navigation">
          {navItems.map((item) => (
            <Link key={item.label} href={item.href}>
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="header-actions">
          <Link className="btn btn-small btn-primary" href="/#quote">
            Get a Free Quote
          </Link>
          <a className="icon-btn" href={brand.whatsappQuote} aria-label="WhatsApp Phantom PPF">
            <MessageCircle size={18} />
          </a>
          <a
            className="icon-btn"
            href={brand.brochure}
            target="_blank"
            rel="noreferrer"
            aria-label="Download Phantom PPF brochure"
          >
            <Download size={18} />
          </a>
          <button
            className="icon-btn menu-toggle"
            type="button"
            aria-label="Open menu"
            onClick={() => setOpen(true)}
          >
            <Menu size={22} />
          </button>
        </div>
      </header>

      <div className={open ? "mobile-menu open" : "mobile-menu"} aria-hidden={!open}>
        <div className="mobile-menu-panel">
          <button
            className="icon-btn close-menu"
            type="button"
            aria-label="Close menu"
            onClick={() => setOpen(false)}
          >
            <X size={22} />
          </button>
          <img className="mobile-logo" src="/assets/logo.webp" alt="Phantom PPF logo" />
          <nav aria-label="Mobile navigation">
            {navItems.map((item) => (
              <Link key={item.label} href={item.href} onClick={() => setOpen(false)}>
                {item.label}
              </Link>
            ))}
          </nav>
          <div className="mobile-menu-actions">
            <Link className="btn btn-primary" href="/#quote" onClick={() => setOpen(false)}>
              Get a Free Quote
            </Link>
            <a className="btn btn-outline" href={brand.whatsappQuote}>
              WhatsApp
            </a>
            <a
              className="btn btn-outline"
              href={brand.brochure}
              target="_blank"
              rel="noreferrer"
            >
              Download Brochure
            </a>
          </div>
        </div>
      </div>

      <div className="mobile-contact-bar" aria-label="Quick contact actions">
        <a href={brand.phoneHref}>
          <Phone size={18} />
          Call
        </a>
        <a href={brand.whatsappQuote}>
          <MessageCircle size={18} />
          WhatsApp
        </a>
        <Link href="/#quote">
          <Download size={18} />
          Get Quote
        </Link>
      </div>
    </>
  );
}
