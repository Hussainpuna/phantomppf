import type { MetadataRoute } from "next";
import { brand, projects, services } from "./site-data";

export default function sitemap(): MetadataRoute.Sitemap {
  const staticRoutes = [
    "",
    "/warranty",
    "/privacy-policy",
    "/terms-and-conditions",
    "/ppf-aftercare-guide",
  ];

  return [
    ...staticRoutes.map((route) => ({
      url: `${brand.siteUrl}${route}`,
      lastModified: new Date("2026-07-14"),
      changeFrequency: "monthly" as const,
      priority: route === "" ? 1 : 0.65,
    })),
    ...services.map((service) => ({
      url: `${brand.siteUrl}/services/${service.slug}`,
      lastModified: new Date("2026-07-14"),
      changeFrequency: "monthly" as const,
      priority: 0.85,
    })),
    ...projects.map((project) => ({
      url: `${brand.siteUrl}/projects/${project.slug}`,
      lastModified: new Date("2026-07-14"),
      changeFrequency: "monthly" as const,
      priority: 0.72,
    })),
  ];
}
