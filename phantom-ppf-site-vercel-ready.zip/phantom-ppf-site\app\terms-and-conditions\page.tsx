import type { Metadata } from "next";
import Link from "next/link";
import { Footer } from "../components/Footer";
import { Header } from "../components/Header";
import { ScrollReveal } from "../components/ScrollReveal";

export const metadata: Metadata = {
  title: "Terms and Conditions | Phantom PPF & Auto Care",
  description:
    "Website terms for Phantom PPF & Auto Care quotations, bookings and service information.",
  alternates: { canonical: "/terms-and-conditions" },
};

export default function Page() {
  return (
    <main>
      <Header />
      <ScrollReveal />
      <section className="plain-hero">
        <div className="section-inner reveal">
          <nav className="breadcrumbs" aria-label="Breadcrumb">
            <Link href="/">Home</Link>
            <span>/</span>
            <strong>Terms and Conditions</strong>
          </nav>
          <span className="section-kicker">Website terms</span>
          <h1>Terms and Conditions</h1>
          <p>
            These terms outline how Phantom PPF & Auto Care presents service information,
            quotations and booking guidance online.
          </p>
        </div>
      </section>
      <section className="section">
        <div className="section-inner narrow-content">
          <h2>Service Information</h2>
          <p>
            Website descriptions are provided for general information. Final recommendations,
            scope, timing and pricing depend on inspection, vehicle condition and selected
            materials.
          </p>
          <h2>Quotations</h2>
          <p>
            Package and service quotes are confirmed by Phantom after reviewing vehicle
            details and requested work.
          </p>
          <h2>External Links</h2>
          <p>
            Brochure, warranty, map and social media links open third-party services. Phantom
            is not responsible for third-party platform availability.
          </p>
          <h2>Warranty</h2>
          <p>
            Warranty details are managed through the official Phantom warranty portal. This
            page does not define warranty duration, coverage or exclusions.
          </p>
        </div>
      </section>
      <Footer />
    </main>
  );
}
