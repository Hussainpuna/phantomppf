import type { Metadata } from "next";
import { HomePage } from "./components/HomePage";
import { brand, featuredServices } from "./site-data";

export const metadata: Metadata = {
  title: "Phantom PPF & Auto Care | Complete Car Protection in the UAE",
  description:
    "Premium PPF, ceramic coating, window tinting, car painting, detailing and oil change services under one roof in Dubai and across the UAE.",
  alternates: { canonical: "/" },
  openGraph: {
    title: "Phantom PPF & Auto Care",
    description:
      "Complete car protection, styling and maintenance in the UAE.",
    images: ["/assets/hero.webp"],
  },
};

const localBusinessSchema = {
  "@context": "https://schema.org",
  "@type": ["AutomotiveBusiness", "LocalBusiness"],
  name: brand.name,
  url: brand.siteUrl,
  image: `${brand.siteUrl}/assets/logo.webp`,
  telephone: brand.phoneDisplay,
  email: brand.email,
  areaServed: "United Arab Emirates",
  openingHours: "Mo-Su 09:00-21:00",
  priceRange: "$$",
  sameAs: [brand.instagram, brand.facebook],
  hasMap: brand.directions,
  makesOffer: featuredServices.map((service) => ({
    "@type": "Offer",
    itemOffered: {
      "@type": "Service",
      name: service.title,
      areaServed: "Dubai, UAE",
    },
  })),
};

export default function Page() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(localBusinessSchema) }}
      />
      <HomePage />
    </>
  );
}
